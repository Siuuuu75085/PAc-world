function player() {
  this.name = "";
  this.score = 0;
}
